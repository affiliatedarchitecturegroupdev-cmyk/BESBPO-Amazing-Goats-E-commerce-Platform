// Wireframe: docs/wireframes/index.html#tp-standing
export default function Standing-ordersPage() {
  return (
    <section>
      <h1>Trade portal: standing-orders</h1>
      <p>TODO(agent): build this screen from wireframe <code>tp-standing</code>. Respect RBAC and the fulfilment tags.</p>
    </section>
  );
}
