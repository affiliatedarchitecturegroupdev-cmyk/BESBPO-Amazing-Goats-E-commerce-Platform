#!/usr/bin/env bash
set -e
corepack enable
pnpm install
