export const tokens = {
  "color": {
    "forest": "#1F3B2D",
    "kalahari": "#B4492B",
    "cream": "#F4ECD8",
    "ochre": "#D6A23E",
    "charcoal": "#25231F"
  },
  "font": {
    "display": "Fraunces, Georgia, serif",
    "body": "Inter, system-ui, sans-serif"
  },
  "radius": {
    "card": "20px",
    "button": "10px"
  }
} as const;
